"""GuideRail smart guided troubleshooting engine."""

__version__ = "0.1.0"
